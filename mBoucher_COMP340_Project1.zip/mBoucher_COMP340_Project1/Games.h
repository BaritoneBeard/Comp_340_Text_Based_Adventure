#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <random>
#include <ctime>
class Games
{
public:
	Games();

	//The following several lines are initiating void methods.  Games are used as my combat action throughout the program. 
	void rockPaperScissors();
	void riggedRockPaperScissors();
	void fingers();
	void riggedFingers();
	bool diceGame();
	void riggedDice();
	bool playerWins();
	void diceRoll();
	void shotgun();

	void riggedCounterOne();
	void riggedCounterTwo();
	void riggedCounterThree();

	int getCountOne();
	int getCountTwo();
	int getCountThree();

private:
	std::vector<std::string > enemyRockChoice;
	std::vector<std::string > enemyShotgunChoice;
	std::vector<int> diceChoice;
	bool win;
	int counterOne = 0;
	int counterTwo = 0;
	int counterThree = 0;
};

