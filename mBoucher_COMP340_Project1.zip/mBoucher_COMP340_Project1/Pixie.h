#pragma once
#include "Bully.h"

//Pixie inherits from Bully.
class Pixie : Bully
{
public:
	Pixie(std::string name);
	bool pickGame();
};

