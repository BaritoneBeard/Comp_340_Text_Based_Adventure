#include "Games.h"
Games::Games()
{
	this->win = false;
}
/*This method plays 'Rock, paper, scissors.'  The enemy has a vector of the three options that are shuffled each turn.  The enemy's choice is the top 
index of the vector.  Several if/else statements are used to determine the winner. 
*/
void Games::rockPaperScissors() {
	enemyRockChoice.push_back("ROCK");
	enemyRockChoice.push_back("PAPER");
	enemyRockChoice.push_back("SCISSORS");
	
	std::string choice;
	std::string endGame;
	std::string randChoice;

	std::cout << "\nHere's how ya play:  Paper covers rock, rock crushes scissors, and scissors cuts paper.  Got it?" << std::endl;
	std::getline(std::cin, endGame);

	while (endGame == "YES") {
		std::cout << "\nOkay.  Let's play!! Rock, Paper, Scissors, Shoot!\n(Enter 'ROCK', 'PAPER' or 'SCISSORS')" << std::endl;
		std::getline(std::cin, choice);

		srand(time(NULL));
		int randomNum = rand() % 100;
		for (int i = 0; i <= randomNum; i++); {
			std::random_shuffle(enemyRockChoice.begin(), enemyRockChoice.end());
		}

		if (choice == "ROCK" && enemyRockChoice[0] == "SCISSORS") {
			std::cout << "\nGosh darn it! I chose " + enemyRockChoice[0] + ". Rock crushes scissors, you beat me!" << std::endl;
			win = true;
			break;
		}
		else if (choice == "ROCK" && enemyRockChoice[0] == "PAPER") {
			std::cout << "\nHAHA!! I chose " + enemyRockChoice[0] + ". Paper covers rock! I WIN!!! Told ya you couldn't beat me!  \n Care to try again? " << std::endl;
			std::getline(std::cin, endGame);
		}
		else if (choice == "PAPER" && enemyRockChoice[0] == "ROCK") {
			std::cout << "\nGosh darn it! I chose " + enemyRockChoice[0] + ". Paper covers rock, you beat me!" << std::endl;
			win = true;
			break;
		}
		else if (choice == "PAPER" && enemyRockChoice[0] == "SCISSORS") {
			std::cout << "\nHAHA!! I chose " + enemyRockChoice[0] + ". Scissors cuts paper! I WIN!!! Told ya you couldn't beat me!  \n Care to try again? " << std::endl;
			std::getline(std::cin, endGame);
		}
		else if (choice == "SCISSORS" && enemyRockChoice[0] == "PAPER") {
			std::cout << "\nGosh darn it! I chose " + enemyRockChoice[0] + ". Scissors cuts paper, you beat me!" << std::endl;
			win = true;
			break;
		}
		else if (choice == "SCISSORS" && enemyRockChoice[0] == "ROCK") {
			std::cout << "\nHAHA!! I chose " + enemyRockChoice[0] + ". Rock crushes scissors! I WIN!!! Told ya you couldn't beat me!  \n Care to try again? " << std::endl;
			std::getline(std::cin, endGame);
		}
		else if (choice == enemyRockChoice[0]) {
			std::cout << "\nAw man!  We both picked " + enemyRockChoice[0] + "!  Let's try this again.  Sound good?" << std::endl;
			std::getline(std::cin, endGame);
		}
		else {
			std::cout << "\nDoncha listen?  I said 'ROCK', 'PAPER' or 'SCISSORS'! Wanna try that again? " << std::endl;
			std::getline(std::cin, endGame);
		}
	}
	playerWins();
}
/*This method is the rigged "rock, paper, scissors." It takes the users input and generates the appropriate response to beat the game using if/else
statements.  The user must play this game 5 times in order for the normal method to be called.*/
void Games::riggedRockPaperScissors() {

	std::string choice;
	std::string enemyChoice;
	std::string endGame;

	std::cout << "\nHere's how ya play:  Paper covers rock, rock crushes scissors, and scissors cuts paper.  Got it?" << std::endl;
	std::getline(std::cin, endGame);

	while (endGame == "YES") {
		std::cout << "\nOkay.  Let's play!! Rock, Paper, Scissors, Shoot!\n(Enter 'ROCK', 'PAPER' or 'SCISSORS')" << std::endl;
		std::getline(std::cin, choice);

		if (choice == "ROCK") {
			riggedCounterOne();
			if (getCountOne() == 5) {
				break;
			}
			std::cout << "\nHAHA!! I chose paper. Paper covers rock! I WIN!!! Told ya you couldn't beat me!  \n Care to try again? " << std::endl;
			break;
		}
		else if (choice == "PAPER") {
			riggedCounterOne();
			if (getCountOne() == 5) {
				break;
			}
			std::cout << "\nHAHA!! I chose scissors. Scissors cuts paper! I WIN!!! Told ya you couldn't beat me!  \n Care to try again? " << std::endl;
			break;
		}
		else if (choice == "SCISSORS") {
			riggedCounterOne();
			if (getCountOne() == 5) {
				break;
			}
			std::cout << "\nHAHA!! I chose rock. Rock crushes scissors! I WIN!!! Told ya you couldn't beat me!  \n Care to try again? " << std::endl;
			break;
		}
		else {
			std::cout << "\nDoncha listen?  I said 'ROCK', 'PAPER' or 'SCISSORS'! Wanna try that again? " << std::endl;
			std::getline(std::cin, endGame);
		}
	}
}
/*This method plays 'How many fingers am I holding up?'  The enemy has a vector of numbers 1-5 that are shuffled each turn.  The enemy's choice is the top
index of the vector.  If/else statements are used to determine the winner.
*/
void Games::fingers() {
	std::string option;
	int choice;
	std::cout << "\nHey there!  Wanna beat me?  You'll have to win first!  My hand is behind my back holding up fingers.  Guess the right amount and you win.  If you don't, you might just get a knuckle sandwich!  Got it?" << std::endl;
	std::getline(std::cin, option);

	while (option =="YES") {
		srand(time(NULL));
		int randomNum = rand() % 5 + 1;
		std::cout << "\nGo ahead.  Make your guess!  How many fingers am I holding up?" << std::endl;
		std::cin >> choice;
		std::cin.ignore();

		if (choice == randomNum) {
			std::cout << "\nYou won this time!  Next time it's a sandwich for you!" << std::endl;
			win = true;
			break;
		}
		else {
			std::cout << "\nHEHEHE I have " << randomNum << " fingers!  You chose wrong and I win!!! \n Wanna give it another try?" << std::endl;
			std::getline(std::cin, option);
		}
	}
	playerWins();
}

/*This method is the rigged "How many fingers am I holding up?" It takes the users input and generates the appropriate response to beat the game using if/else
statements.  The user must play this game 5 times in order for the normal method to be called.*/
void Games::riggedFingers() {
	std::string option;
	int choice;
	std::cout << "\nHey there!  Wanna beat me?  You'll have to win first!  My hand is behind my back holding up fingers.  Guess the right amount and you win.  If you don't, you might just get a knuckle sandwich!  Got it?" << std::endl;
	std::getline(std::cin, option);

	while (option =="YES") {
		srand(time(NULL));
		int randomNum = rand() % 5 + 1;
		std::cout << "\nGo ahead.  Make your guess!  How many fingers am I holding up?" << std::endl;
		std::cin >> choice;
		std::cin.ignore();

		if (choice == randomNum && randomNum <5) {
			randomNum = randomNum + 1;
			riggedCounterTwo();
			if (getCountTwo() == 5) {
				break;
			}
			std::cout << "\nHEHEHE I have " << randomNum << " fingers!  You chose wrong and I win!!! \n Wanna give it another try?" << std::endl;
			std::getline(std::cin, option);
		}
		else if (choice == randomNum && randomNum == 5) {
			randomNum = randomNum - 2;
			riggedCounterTwo();
			if (getCountTwo() == 5) {
				break;
			}
			std::cout << "\nHEHEHE I have " << randomNum << " fingers!  You chose wrong and I win!!! \n Wanna give it another try?" << std::endl;
			std::getline(std::cin, option);
		}
		else {
			std::cout << "\nHEHEHE I have " << randomNum << " fingers!  You chose wrong and I win!!! \n Wanna give it another try?" << std::endl;
			riggedCounterTwo();
			if (getCountTwo() == 5) {
				break;
			}
			std::getline(std::cin, option);
		}
	}
}

//This method simulates rolling dice by pushing numbers 1-6 to a vector, shuffling the vector, then choosing the top index.
void Games::diceRoll() {
	diceChoice.push_back(1);
	diceChoice.push_back(2);
	diceChoice.push_back(3);
	diceChoice.push_back(4);
	diceChoice.push_back(5);
	diceChoice.push_back(6);

	srand(time(NULL));
	int randomNum = rand() % 10;
	for (int i = 0; i <= randomNum; i++); {
		std::random_shuffle(diceChoice.begin(), diceChoice.end());
	}
}
//This method allows a player to continue rolling the die until they reach a sum of 10 or higher.  If they choose to pass, the enemy has the opportunity to roll.
//The method uses several if/else statements to determine the winner. 
bool Games::diceGame() {
	std::string choice;
	int playerSum = 0;
	int bullySum = 0;

	std::cout << "\nLet's play my dice game!  Here are the rules: \n1. Roll the dice as many times you want. \n2. Aim for the number 10. \n3. If you go over you lose. \n4. You get 10 exactly you win. \n5. You get less than 10 but are higher than me, you win!\n" << std::endl;
	std::cout << "\nGot it?  Let's begin! \n'ROLL' or 'PASS'?" << std::endl;
	std::getline(std::cin, choice);

	while (choice != "PASS") {
		diceRoll();
		playerSum = playerSum + diceChoice[0];
		std::cout << "\nYou rolled " << diceChoice[0] << std::endl;

		if (playerSum > 10) {
			std::cout << "\nYou have " << playerSum << " You bust! You lose!" << std::endl;
			break;
		}
		else if (playerSum < 10) {
			std::cout << "\nYou have " << playerSum << ". 'ROLL' or 'PASS'" << std::endl;
			std::getline(std::cin, choice);
		}
		else if (playerSum == 10) {
			std::cout << "\nYou got 10! You win!!" << std::endl;
			this-> win = true;
			break;
		}
		else {
			std::cout << "\n'ROLL' or 'PASS'?" << std::endl;
			std::getline(std::cin, choice);
		}
	}
	if (playerSum < 10) {
		while (bullySum < 7) {
			diceRoll();
			bullySum = bullySum + diceChoice[0];
			std::cout << "\nI rolled " << diceChoice[0] << std::endl;
		}
		std::cout << "\nYour score: " << playerSum << "\nMy score: " << bullySum << std::endl;
		if (bullySum > 10) {
			std::cout << "\nUgh I bust. You won this time." << std::endl;
			this->win = true;
		}
		else if (bullySum == 10) {
			std::cout << "\nHAHA I WIN!!!" << std::endl;
		}
		else if (playerSum > bullySum) {
			std::cout << "\nUgh. You won this time." << std::endl;
			this-> win = true;
		}
		else if (playerSum < bullySum) {
			std::cout << "\nHAHA I WIN!!!" << std::endl;
		}
		else {
			std::cout << "\nWe tied...no one wins this time." << std::endl;
		}
	}
	return playerWins();
}

//This method is the rigged version of the dice game.  The player will win if they roll a 10, however the enemy will always roll a 10.
void Games::riggedDice() {
	std::string choice;
	int playerSum = 0;
	int bullySum = 0;

	std::cout << "\nLet's play my dice game!  Here are the rules: \n1. Roll the dice as many times you want. \n2. Aim for the number 10. \n3. If you go over you lose. \n4. You get 10 exactly you win. \n5. You get less than 10 but are higher than me, you win!\n" << std::endl;
	std::cout << "\nGot it?  Let's begin! \n'ROLL' or 'PASS'" << std::endl;
	std::getline(std::cin, choice);

	while (choice != "PASS") {
		diceRoll();
		playerSum = playerSum + diceChoice[0];
		std::cout << "\nYou rolled " << diceChoice[0] << std::endl;

		if (playerSum > 10) {
			riggedCounterThree();
			if (getCountThree() == 5) {
				break;
			}
			std::cout << "\nYou have " << playerSum << " You bust! You lose!" << std::endl;
			break;
		}
		else if (playerSum < 10) {
			std::cout << "\nYou have " << playerSum << ". 'ROLL' or 'PASS'?" << std::endl;
			std::getline(std::cin, choice);
		}
		else if (playerSum == 10) {
			std::cout << "\nYou got 10! You win!!" << std::endl;
			break;
		}
		else {
			std::cout << "\n'ROLL' or 'PASS'?" << std::endl;
			std::getline(std::cin, choice);
		}
	}
	if (playerSum < 10) {
		riggedCounterThree();
		bullySum == 10;
		std::cout << "\nHAHA I WIN!!!" << std::endl;
	}
	playerWins();
}

//The following six methods track how many rigged games have been played. 
void Games::riggedCounterOne() {
	counterOne = counterOne + 1;
}
int Games::getCountOne() {
	return counterOne;
}

void Games::riggedCounterTwo() {
	counterTwo = counterTwo + 1;
}
int Games::getCountTwo() {
	return counterTwo;
}

void Games::riggedCounterThree() {
	counterThree = counterThree + 1;
}
int Games::getCountThree() {
	return counterThree;
}
//This method tracks the winner of the game. 
bool Games::playerWins() {
	if (win) {
		return true;
	}
	else {
		return false;
	}
}

//This method is the final fight of the game. The enemy has a vector with three items that are shuffled.  The enemy then uses the top index as it's choice.
//Several if/else statements of performed to determine a winner. 
void Games::shotgun() {
	enemyShotgunChoice.push_back("RELOAD");
	enemyShotgunChoice.push_back("SHOOT");
	enemyShotgunChoice.push_back("BLOCK");

	std::cout << "\nBoss fight!!" << std::endl;
	std::string choice;
	std::string endGame;
	std::string randChoice;
	bool correctBossChoice = true;
	int bossPower = 1;
	int playerPower = 1;

	std::cout << "\nHere's how ya play:\nYour options are 'RELOAD', 'SHOOT', and 'BLOCK'.\nIf you're out of ammo, you must reload before you can shoot.\nYou may reload up to 3 times before shooting for higher power.\nWhen you shoot, you shoot all ammo.\nIf we both shoot, the person with the highest power wins.\nIf one is reloading while the other shoots, the person shooting wins.\nIf someone shoots while the other is blocking, the person shooting loses their ammo.\nGot it?" << std::endl;
	std::cout << "\nOkay.  Let's play!  We both start at reload giving us each 1 ammo. Make your choice." << std::endl;
	std::getline(std::cin, endGame);
	while (true) {
		
		while (true)
		{
			srand(time(NULL));
			int randomNum = rand() % 100;
			for (int i = 0; i <= randomNum; i++); {
				std::random_shuffle(enemyShotgunChoice.begin(), enemyShotgunChoice.end());
			}
			if (enemyShotgunChoice[0] == "SHOOT" && bossPower < 1)
			{
				correctBossChoice = false;
			}
			else if (enemyShotgunChoice[0] == "RELOAD" && bossPower > 2)
			{
				correctBossChoice = false;
			}
			else
			{
				correctBossChoice = true;
			}
			if (correctBossChoice == true)
			{
				break;
			}
		}
		if (endGame == "RELOAD" && playerPower == 3) {
			std::cout << "\nYou can't reload more than 3!  Try again!  Make your choice: " << std::endl;
			std::getline(std::cin, endGame);
		}
		else if (endGame == "RELOAD" && playerPower < 3) {
			if (enemyShotgunChoice[0] == "RELOAD" && bossPower == 3) {
				std::cout << "\nI chose " +  enemyShotgunChoice[1] + "." << std::endl;
				if (enemyShotgunChoice[1] == "SHOOT") {
					std::cout << "\nHAHAHAHAHA I WIN!!" << std::endl;
					break;
				}
				else {
					playerPower = playerPower + 1;
				}
			}
			else if (enemyShotgunChoice[0] == "RELOAD" && bossPower < 3) {
				bossPower = bossPower + 1;
				playerPower = playerPower + 1;
				std::cout << "\nI chose " + enemyShotgunChoice[0] + "." << std::endl;
			}
			else if (enemyShotgunChoice[0] == "SHOOT") {
				std::cout << "\nI chose " + enemyShotgunChoice[0] + "." << std::endl;
				std::cout << "\nHAHAHAHAHA I WIN!!" << std::endl;
				break;
			}
			else {
				std::cout << "\nI chose " + enemyShotgunChoice[0] + "." << std::endl;
				playerPower = playerPower + 1;
			}

			std::cout << "\nI have " << bossPower << " ammo. \nYou have " << playerPower << " ammo. \nMake your choice: " << std::endl;
			std::getline(std::cin, endGame);
		}
		else if (endGame == "BLOCK") {
			std::cout << "\nI chose " + enemyShotgunChoice[0] + "." << std::endl;
			if (enemyShotgunChoice[0] == "SHOOT") {
				bossPower = 0;
			}
			else if (enemyShotgunChoice[0] == "RELOAD") {
				bossPower = bossPower + 1;
			}
			std::cout << "\nI have " << bossPower << " ammo. \nYou have " << playerPower << " ammo. \nMake your choice: " << std::endl;
			std::getline(std::cin, endGame);
		}
		else if (endGame == "SHOOT" && playerPower == 0) {
			std::cout << "\nYou can't shoot with no ammo."<< std::endl;
			std::getline(std::cin, endGame);
		}
		else if (endGame == "SHOOT" && playerPower > 0) {
			std::cout << "\nI chose " + enemyShotgunChoice[0] + "." << std::endl;
			if (enemyShotgunChoice[0] == "SHOOT") {
				if (bossPower == playerPower) {
					playerPower = 0;
					bossPower = 0;
					std::cout << "\nI have " << bossPower << " ammo. \nYou have " << playerPower << " ammo. \nMake your choice: " << std::endl;
					std::getline(std::cin, endGame);
				}
				else if (bossPower > playerPower) {
					std::cout << "\nHAHAHAHAHA I WIN!!" << std::endl;
					break;
				}
				else {
					std::cout << "\nUGHHHHHH You bested me!" << std::endl;
					win = true;
					break;
				}
			}
			else if (enemyShotgunChoice[0] == "BLOCK") {
				playerPower = 0;
				std::cout << "\nI have " << bossPower << " ammo. \nYou have " << playerPower << " ammo. \nMake your choice: " << std::endl;
				std::getline(std::cin, endGame);
			}
			else {
				std::cout << "\nUGHHHHHH You bested me!" << std::endl;
				win = true;
				break;
			}
		}
		else {
			std::cout << "\nDoncha listen?  I said 'RELOAD', 'SHOOT', and 'BLOCK'! Wanna try that again? " << std::endl;
			std::getline(std::cin, endGame);
		}
	}
	playerWins();
}