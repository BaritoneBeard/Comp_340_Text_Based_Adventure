#pragma once
#include "Bully.h"

//Monkey inherits from Bully.
class Monkey : public Bully
{
public:
	Monkey(std::string name);
	
	bool pickGame();

private:
	
};

