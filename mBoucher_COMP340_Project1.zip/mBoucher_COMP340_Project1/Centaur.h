#pragma once
#include "Bully.h"

//Centaur inherits from Bully.
class Centaur : Bully
{
public:
	Centaur(std::string name);
	bool pickGame();
};

